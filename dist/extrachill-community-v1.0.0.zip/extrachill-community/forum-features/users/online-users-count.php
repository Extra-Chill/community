<?php

// Global variable to store online user count
global $online_users_count;

function record_user_activity() {
    $user_id = get_current_user_id();
    if ($user_id) {
        $current_time = current_time('timestamp');
        
        // Use a more efficient approach with transient caching
        $user_activity_cache_key = 'user_activity_' . $user_id;
        $last_update = get_transient($user_activity_cache_key);
        
        // Only update if 15 minutes have passed (900 seconds) - increased from 5 minutes
        if (false === $last_update || ($current_time - intval($last_update)) > 900) {
            // Update the last_active meta
            update_user_meta($user_id, 'last_active', $current_time);
            
            // Set a transient to track when we last updated for this user
            set_transient($user_activity_cache_key, $current_time, 900); // 15 minutes
            
            // Clear the online users count cache since we updated activity
            delete_transient('online_users_count');
        }
    }

    // Fetch the current online user count using our cached function
    global $online_users_count;
    if (!isset($online_users_count)) {
        $online_users_count = get_online_users_count();
    }

    // Update most ever online if needed (but cache this check too)
    $most_ever_cache_key = 'most_ever_online_check';
    $last_most_ever_check = get_transient($most_ever_cache_key);
    
    if (false === $last_most_ever_check) {
        $most_ever_online = get_option('most_ever_online', ['count' => 0, 'date' => '']);
        $most_ever_online_count = intval($most_ever_online['count']);

        if ($online_users_count > $most_ever_online_count) {
            $most_ever_online = [
                'count' => $online_users_count,
                'date' => current_time('m/d/Y')
            ];
            update_option('most_ever_online', $most_ever_online);
        }
        
        // Cache this check for 5 minutes to avoid frequent option updates
        set_transient($most_ever_cache_key, current_time('timestamp'), 300);
    }
}
add_action('wp', 'record_user_activity');

function get_online_users_count() {
    global $wpdb;

    // Use transient to cache the result
    $transient_key = 'online_users_count';
    $online_users_count = get_transient($transient_key);

    if ($online_users_count === false) {
        $time_limit = 15 * MINUTE_IN_SECONDS; // 15 minutes ago
        $time_threshold = current_time('timestamp') - $time_limit;

        $online_users_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $wpdb->usermeta WHERE meta_key = 'last_active' AND meta_value > %d",
            $time_threshold
        ));

        // Cache the result for 5 minutes
        set_transient($transient_key, intval($online_users_count), 5 * MINUTE_IN_SECONDS);
    }

    return intval($online_users_count);
}

function display_online_users_stats() {
    global $online_users_count;

    if (!isset($online_users_count)) {
        $online_users_count = get_online_users_count();
    }

    $most_ever_online = get_option('most_ever_online', ['count' => 0, 'date' => '']);

    // Ensure we have the 'count' as an integer and 'date' as a string
    $most_ever_online_count = isset($most_ever_online['count']) ? (int)$most_ever_online['count'] : 0;
    $most_ever_online_date = isset($most_ever_online['date']) ? date('m/d/Y', strtotime($most_ever_online['date'])) : 'N/A';

    // Use transient to cache the total members count
    $transient_key_total_members = 'total_members_count';
    $total_members = get_transient($transient_key_total_members);

    if ($total_members === false) {
        $user_count_data = count_users();
        $total_members = $user_count_data['total_users'];
        set_transient($transient_key_total_members, $total_members, 24 * HOUR_IN_SECONDS); // Cache for 24 hours
    }

    echo "<div class='online-stats'>";
    echo "<p><span class='label'>Users Currently Online:</span> <span class='count'>" . $online_users_count . "</span></p>";
    // Most Ever Online tracking continues but display is hidden
    // echo "<p><span class='label'>Most Ever Online:</span> <span class='count'>" . $most_ever_online_count . "</span> on <span class='date'>" . $most_ever_online_date . "</span></p>";
    echo "<p><span class='label'>Total Members:</span> <span class='count'>" . $total_members . "</span></p>";
    echo "</div>";
}
